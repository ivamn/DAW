'use strict';

const SERVER = 'http://arturober.com:5007/';