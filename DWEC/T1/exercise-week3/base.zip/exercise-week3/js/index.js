"use strict";

window.addEventListener("DOMContentLoaded", e => {
    
});

