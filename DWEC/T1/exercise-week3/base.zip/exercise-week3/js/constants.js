'use strict';

const SERVER = 'http://localhost:3000';
