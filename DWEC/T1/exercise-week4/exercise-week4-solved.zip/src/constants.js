'use strict';

export const SERVER = 'http://arturober.com:5007/';