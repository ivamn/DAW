"use strict";

let newProductForm = null;
let errorMsg = null;

window.addEventListener("DOMContentLoaded", e => {
    
});

