<?php

namespace TODO\core\database;

use PDO;
use TODO\core\App;

abstract class QueryBuilder
{
    public static string $SORT_ORDER_RANDOM = "RANDOM";
    public static string $SORT_ORDER_NONE = "NONE";

    private PDO $connection;
    private string $table;
    private string $entityClass;

    /**
     * QueryBuilder constructor.
     * @param string $table
     * @param string $entityClass
     */
    public function __construct(string $table, string $entityClass)
    {
        $this->connection = App::get("connection");
        $this->table = $table;
        $this->entityClass = $entityClass;
    }

    public function findAll(): array
    {
        $sql = "select * from $this->table;";
        $pdoStatement = $this->connection->prepare($sql);
        $pdoStatement->execute();
        return $pdoStatement->fetchAll(PDO::FETCH_CLASS, $this->entityClass);
    }

    /**
     * @param int $length Length of the rows returned.
     * @param string $sort The sorting criteria, it can be either random (QueryBuilder::$SORT_ORDER_RANDOM) or the column name, default is none,
     * @param int $start The starting point of the rows returned.
     * @return array The rows found.
     */
    protected function findSome(int $length, string $sort = "NONE", int $start = 0): array
    {
        $sqlSort = "";
        if ($sort !== self::$SORT_ORDER_NONE) {
            $sqlSort = strcmp($sort, self::$SORT_ORDER_RANDOM) === 0 ? "ORDER BY RAND()" : "ORDER BY $sort";
        }
        $limitSql = $start !== 0 ? "LIMIT $start, $length" : "LIMIT $length";
        $sql = "select * from $this->table $sqlSort $limitSql;";
        $pdoStatement = $this->connection->prepare($sql);
        $pdoStatement->execute();
        return $pdoStatement->fetchAll(PDO::FETCH_CLASS, $this->entityClass);
    }

    public function find(int $id): ?IEntity
    {
        $sql = "select * from $this->table where id=$id;";
        $pdoStatement = $this->connection->prepare($sql);
        $pdoStatement->execute();
        $pdoStatement->setFetchMode(PDO::FETCH_CLASS, $this->entityClass);
        return $pdoStatement->fetch(PDO::FETCH_CLASS);
    }

    protected function findAllBy(array $conditions, bool $and = true, bool $isText = false): array
    {
        $wheres = [];
        $glue = $and ? "and" : "or";
        foreach ($conditions as $column => $condition) {
            if ($isText) {
                array_push($wheres, "$column LIKE '%$condition%'");
            } else {
                array_push($wheres, "$column = '$condition'");
            }
        }
        $where = "";
        if (count($wheres) > 0) {
            $where = "where " . implode(" $glue ", $wheres);
        }
        $sql = "select * from $this->table $where";
        $pdoStatement = $this->connection->prepare($sql);
        $pdoStatement->execute();
        return $pdoStatement->fetchAll(PDO::FETCH_CLASS, $this->entityClass);
    }

    protected function findOneBy(array $conditions, bool $and = true, bool $isText = false): ?IEntity
    {
        $entities = $this->findAllBy($conditions, $and, $isText);
        return array_shift($entities);
    }

    public function save(IEntity $entidad): bool
    {
        $parametros = $entidad->toArray();

        $campos = implode(', ', array_keys($parametros));
        $valores = ':' . implode(', :', array_keys($parametros));
        $sql = sprintf(
            "INSERT INTO %s (%s) VALUES (%s);",
            $this->table,
            $campos,
            $valores
        );
        $pdoStatement = $this->connection->prepare($sql);
        return $pdoStatement->execute($parametros);
    }

    public function update(IEntity $entidad): bool
    {
        $parametros = $entidad->toArray();

        $campos = '';
        foreach ($parametros as $nombre => $valor)
            $campos .= "$nombre=:$nombre, ";
        $campos = rtrim($campos, ', ');

        $sql = sprintf(
            "UPDATE %s set %s WHERE id = %s;",
            $this->table,
            $campos,
            $entidad->getId()
        );
        $pdoStatement = $this->connection->prepare($sql);
        return $pdoStatement->execute($parametros);
    }

    public function delete(IEntity $entity) : bool
    {
        $sql = sprintf(
            "DELETE FROM %s WHERE id = :id;",
            $this->table
        );
        $pdoStatement = $this->connection->prepare($sql);

        $id = $entity->getId();
        $pdoStatement->bindParam('id', $id);
        return $pdoStatement->execute();
    }

    /**
     * @return PDO
     */
    public function getConnection()
    {
        return $this->connection;
    }

    /**
     * @return string
     */
    public function getTable(): string
    {
        return $this->table;
    }

    /**
     * @return string
     */
    public function getEntityClass(): string
    {
        return $this->entityClass;
    }

    public function count(): int
    {
        return $this->connection->query("select count(*) from $this->table")->fetchColumn();
    }
}