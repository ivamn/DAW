<?php


namespace TODO\core;


class Security
{
    public static function isUserGranted(string $role): bool
    {
        if ($role === "ROLE_ANON") {
            return true;
        }

        $user = App::get("user");
        if (is_null($user)) {
            return false;
        }
        $userRepository = App::get("userRepository");
        $userRole = $userRepository->getRole($user)->getName();
        $roles = App::get("config")["security"]["roles"];
        return !($roles[$role] > $roles[$userRole]);
    }
}