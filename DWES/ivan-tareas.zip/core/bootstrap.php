<?php

use TODO\app\repository\PrioridadRepository;
use TODO\app\repository\TareasRepository;
use TODO\core\App;
use TODO\core\database\Connection;

session_start();

require_once __DIR__ . "/../vendor/autoload.php";

$config = require __DIR__ . '/../app/config.php';

App::bind("config", $config);
App::bind("connection", Connection::make($config['database']));;

App::bind("tareasRepository", new TareasRepository());
App::bind("prioridadRepository", new PrioridadRepository());