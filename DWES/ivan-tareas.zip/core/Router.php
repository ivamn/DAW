<?php

namespace TODO\core;

use Exception;

class Router
{
    private array $routes = [
        "GET" => [],
        "POST" => []
    ];

    public function get(string $uri, string $controller, string $action)
    {
        $this->routes["GET"][$uri] = $controller . "@" . $action;
    }

    public function post(string $uri, string $controller, string $action, string $role = "ROLE_ANON")
    {
        $this->routes["POST"][$uri] = $controller . "@" . $action;
    }

    public function delete(string $uri, string $controller, string $action)
    {
        $this->routes["DELETE"][$uri] = $controller . "@" . $action;
    }

    public function direct(string $uri, string $method)
    {
        foreach ($this->routes[$method] as $route => $controller) {
            $urlRule = $this->prepareRoute($route);
            if (preg_match('/^' . $urlRule . '\/*$/s', $uri, $matches)) {
                $parameters = $this->getParametersRoute($route, $matches);
                list($controller, $action) = explode('@', $controller);

                return $this->callAction($controller, $action, $parameters);
            }
        }

        throw new \Exception('Route not defined');
    }

    private function prepareRoute(string $route)
    {
        $urlRule = preg_replace(
            '/:([^\/]+)/',
            '(?<\1>[0-9]+)',
            $route
        );

        return str_replace('/', '\/', $urlRule);
    }

    private function getParametersRoute(string $route, array $matches)
    {
        preg_match_all('/:([^\/]+)/', $route, $parameterNames);
        return array_intersect_key($matches, array_flip($parameterNames[1]));
    }

    public static function load(string $file)
    {
        App::bind("router", new static());
        require $file;
    }

    public function redirect(string $path)
    {
        header('location: /' . $path);
        exit;
    }

    private function callAction(string $controller, string $action, array $parameters)
    {
        $objController = new $controller;
        if (!method_exists($objController, $action)) {
            throw new Exception(
                "Controller: $controller can not call the action: $action");
        }
        call_user_func_array([$objController, $action], $parameters);
        return true;
    }
}