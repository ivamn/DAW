'use strict';

document.addEventListener("DOMContentLoaded", (event) => {
    let filterButton = document.getElementById('filter-button');
    filterButton.addEventListener('click', async (event) => {
        const {value: formValues} = await Swal.fire({
            title: 'Filter by date',
            showCancelButton: true,
            html:
                '<input name="swal-input1" id="swal-input1" type="date" class="swal2-input">' +
                '<input name="swal-input2" id="swal-input2" type="date" class="swal2-input">',
            focusConfirm: false,
            preConfirm: () => {
                return [
                    document.getElementById('swal-input1').value,
                    document.getElementById('swal-input2').value
                ]
            }
        })

        if (formValues) {
            location.assign(`home?from_date=${formValues[0]}&to_date=${formValues[1]}`)
        }
    })

    let removeFilterButton = document.getElementById('remove-filter-button');
    removeFilterButton.addEventListener('click', event => {
        location.assign('home');
    })
});