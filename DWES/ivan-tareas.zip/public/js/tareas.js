'use strict';

document.addEventListener("DOMContentLoaded", e => {
    let buttons = document.querySelectorAll('.btn-danger');

    buttons.forEach(boton => {
        boton.addEventListener('click', function (event) {
            event.preventDefault();
            fetch(this.href, {method: 'DELETE'})
                .then(resp => {
                    this.parentElement.parentElement.parentElement.remove();
                });
        });
    })
});