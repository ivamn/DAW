<?php

use TODO\core\App;
use TODO\core\Request;
use TODO\core\Router;

require __DIR__ . "/../core/bootstrap.php";

Router::load(__DIR__ . "/../app/routes.php");

App::get("router")->direct(Request::uri(), Request::method());