<?php


namespace TODO\app\repository;


use TODO\app\entity\Tarea;
use TODO\core\App;
use TODO\core\database\QueryBuilder;

class TareasRepository extends QueryBuilder
{
    public function __construct()
    {
        parent::__construct("tarea", Tarea::class);
    }

    public function getPrioridad(Tarea $tarea)
    {
        return App::get("prioridadRepository")->find($tarea->getPrioridad());
    }

    public function getByPrioridad(int $prioridad)
    {
        return $this->findAllBy(
            ["prioridad" => $prioridad]
        );
    }
}