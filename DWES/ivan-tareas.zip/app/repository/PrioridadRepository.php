<?php


namespace TODO\app\repository;


use TODO\app\entity\Prioridad;

class PrioridadRepository extends \TODO\core\database\QueryBuilder
{
public function __construct()
{
    parent::__construct("prioridad", Prioridad::class);
}
}