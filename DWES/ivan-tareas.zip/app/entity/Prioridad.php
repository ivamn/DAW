<?php


namespace TODO\app\entity;

use TODO\core\database\IEntity;

class Prioridad implements IEntity
{
    private int $id;
    private string $descripcion;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param int $id
     * @return Prioridad
     */
    public function setId(int $id): Prioridad
    {
        $this->id = $id;
        return $this;
    }

    /**
     * @return string
     */
    public function getDescripcion(): string
    {
        return $this->descripcion;
    }

    /**
     * @param string $descripcion
     * @return Prioridad
     */
    public function setDescripcion(string $descripcion): Prioridad
    {
        $this->descripcion = $descripcion;
        return $this;
    }

    public function toArray(): array
    {
        return [
            "descripcion" => $this->descripcion
        ];
    }


}