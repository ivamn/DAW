<?php


namespace TODO\app\entity;


use TODO\core\database\IEntity;

class Tarea implements IEntity
{
    private int $id;
    private string $nombre;
    private string $descripcion;
    private int $prioridad;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param int $id
     * @return Tarea
     */
    public function setId(int $id): Tarea
    {
        $this->id = $id;
        return $this;
    }

    /**
     * @return string
     */
    public function getNombre(): string
    {
        return $this->nombre;
    }

    /**
     * @param string $nombre
     * @return Tarea
     */
    public function setNombre(string $nombre): Tarea
    {
        $this->nombre = $nombre;
        return $this;
    }

    /**
     * @return string
     */
    public function getDescripcion(): string
    {
        return $this->descripcion;
    }

    /**
     * @param string $descripcion
     * @return Tarea
     */
    public function setDescripcion(string $descripcion): Tarea
    {
        $this->descripcion = $descripcion;
        return $this;
    }

    /**
     * @return int
     */
    public function getPrioridad(): int
    {
        return $this->prioridad;
    }

    /**
     * @param int $prioridad
     * @return Tarea
     */
    public function setPrioridad(int $prioridad): Tarea
    {
        $this->prioridad = $prioridad;
        return $this;
    }


    public function toArray(): array
    {
        return [
            "nombre" => $this->nombre,
            "descripcion" => $this->descripcion,
            "prioridad" => $this->prioridad
        ];
    }

}