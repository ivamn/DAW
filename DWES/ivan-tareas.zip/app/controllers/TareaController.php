<?php


namespace TODO\app\controllers;


use TODO\app\entity\Tarea;
use TODO\core\App;
use TODO\core\Response;

class TareaController
{
    public function index()
    {
        $prioridadRepository = App::get("prioridadRepository");
        $tareasRepository = App::get("tareasRepository");

        $q = $_GET["q"] ?? 0;
        $q = intval($q);
        if ($q === 0) {
            $tareas = $tareasRepository->findAll();
        } else {
            $tareas = $tareasRepository->getByPrioridad($q);
        }
        $prioridades = $prioridadRepository->findAll();
        Response::renderView("home", [
            "tareas" => $tareas,
            "tareasRepository" => $tareasRepository,
            "q" => $q,
            "prioridades" => $prioridades
        ]);
    }

    public function tarea(int $id)
    {
        $tareasRepository = App::get("tareasRepository");
        $tarea = $tareasRepository->find($id);
        Response::renderView("tarea", [
            "tarea" => $tarea,
            "tareasRepository" => $tareasRepository
        ]);
    }

    public function postAddTarea()
    {
        $tarea = new Tarea();
        $tarea->setNombre($_POST["nombre"])->setDescripcion($_POST["descripcion"])->setPrioridad($_POST["prioridad"]);
        $rep = App::get("tareasRepository");
        $rep->save($tarea);
        App::get("router")->redirect("");
    }

    public function getAddTarea()
    {
        $prioridadRepository = App::get("prioridadRepository");
        $prioridades = $prioridadRepository->findAll();
        Response::renderView("add-tarea-form", [
            "prioridades" => $prioridades
        ]);
    }

    public function editTarea(int $id)
    {
        $tareasRepository = App::get("tareasRepository");
        $tarea = $tareasRepository->find($id);
        $prioridadRepository = App::get("prioridadRepository");
        $prioridades = $prioridadRepository->findAll();
        Response::renderView("edit-tarea-form", [
            "prioridades" => $prioridades,
            "tarea" => $tarea
        ]);
    }

    public function postEditTarea(int $id)
    {
        $tarea = new Tarea();
        $tarea->setNombre($_POST["nombre"])->setDescripcion($_POST["descripcion"])->setPrioridad($_POST["prioridad"])->setId($id);
        $rep = App::get("tareasRepository");
        $rep->update($tarea);
        App::get("router")->redirect("");
    }

    public function removeTarea(int $id)
    {
        $rep = App::get("tareasRepository");
        $rep->delete($id);
        header('Content-Type: application/json');
    }
}