<section class="contact-area section-padding-100">
    <div class="container">
        <?php require __DIR__ . "/partials/tarea.php"; ?>
    </div>
</section>