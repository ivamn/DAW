<section class="contact-area section-padding-100">
    <div class="container">
        <div class="row border-bottom pb-3 justify-content-between mb-3">
            <p class="travelers-title col-6">Tareas</p>
            <form class="col-6 d-flex justify-content-end" action="/tarea" method="get">
                <label for="select" class="mx-3">Filtro de prioridad</label>
                <select name="q" id="select" class="px-3">
                    <option <?= $q === 0 ? "selected" : "" ?> value="0">Sin filtro</option>
                    <?php foreach ($prioridades as $prioridad): ?>
                        <option <?= $q === $prioridad->getId() ? "selected" : "" ?>
                                value="<?= $prioridad->getId(); ?>"><?= $prioridad->getDescripcion(); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn world-btn mx-4">
                    <i class="fa fa-search"></i>
                </button>
            </form>
        </div>

        <?php foreach ($tareas as $tarea): ?>
            <?php require __DIR__ . "/partials/tarea.php"; ?>
        <?php endforeach; ?>
    </div>
</section>

</body>

</html>