<section class="contact-area section-padding-100">
    <div class="container">
        <div class="row justify-content-center">
            <!-- Contact Form Area -->
            <div class="col-12 col-md-10 col-lg-8">
                <div class="contact-form">
                    <h5>Editar tarea</h5>
                    <!-- Contact Form -->
                    <form action="/tarea/<?= $tarea->getId() ?>/edit" method="post">
                        <div class="row">
                            <div class="col-12">
                                <div class="group">
                                    <input type="text" name="nombre" id="nombre" required value="<?= $tarea->getNombre(); ?>">
                                    <span class="highlight"></span>
                                    <span class="bar"></span>
                                    <label>Nombre</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="group">
                                    <input type="text" name="descripcion" id="descripcion" required value="<?= $tarea->getDescripcion() ?? ""; ?>">
                                    <span class="highlight"></span>
                                    <span class="bar"></span>
                                    <label>Descripcion</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="group">
                                    <select name="prioridad" id="prioridad" required>
                                        <?php foreach ($prioridades as $prioridad): ?>
                                            <option value="<?= $prioridad->getId(); ?>"><?= $prioridad->getDescripcion(); ?></option>
                                        <?php endforeach;?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn world-btn">Edit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

</body>

</html>