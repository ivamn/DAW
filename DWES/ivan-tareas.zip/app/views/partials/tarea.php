<div class="d-flex flex-column mb-3 border p-4">
    <a href="/tarea/<?= $tarea->getId(); ?>" class="headline">
        <h5><?= $tarea->getNombre(); ?></h5>
    </a>
    <p><?= $tarea->getDescripcion(); ?></p>
    <div class="alert alert-secondary w-100" role="alert">
        Prioridad: <?= $tareasRepository->getPrioridad($tarea)->getDescripcion(); ?>
    </div>
    <div class="row px-3">
        <a href="/tarea/<?= $tarea->getId(); ?>/edit" class="mx-3">
            <button class="btn btn-primary">Editar</button>
        </a>
        <a href="/tarea/remove/<?= $tarea->getId(); ?>" class="mx-3 .delete">
            <button class="btn btn-danger">Eliminar</button>
        </a>
    </div>
</div>