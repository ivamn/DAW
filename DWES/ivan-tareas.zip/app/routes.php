<?php

use TODO\app\controllers\TareaController;
use TODO\core\App;

$router = App::get("router");
$router->get("", TareaController::class, "index");
$router->get("tarea", TareaController::class, "index");
$router->get("tarea/:id", TareaController::class, "tarea");
$router->get("tarea/:id/edit", TareaController::class, "editTarea");
$router->post("tarea/:id/edit", TareaController::class, "postEditTarea");
$router->get("tarea/:id/remove", TareaController::class, "removeTarea");
$router->get("tarea/add", TareaController::class, "getAddTarea");
$router->post("tarea/add", TareaController::class, "postAddTarea");
$router->delete("tarea/remove/:id", TareaController::class, "removeTarea");
